using UnityEngine;

public class Door : MonoBehaviour
{
    [SerializeField] private Transform previousRoom;
    [SerializeField] private Transform nextRoom;
    [SerializeField] private CameraController cam;

    private void Awake()
    {
        cam = Camera.main.GetComponent<CameraController>();
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.tag == "Player")
        {
            if (nextRoom == null || previousRoom == null)
            {
                Debug.LogError("nextRoom or previousRoom is not assigned!");
                return;
            }

            if (collision.transform.position.x < transform.position.x)
            {
                cam.MoveToNewRoom(nextRoom);
                var nextRoomComponent = nextRoom.GetComponent<Room>();
                var previousRoomComponent = previousRoom.GetComponent<Room>();

                if (nextRoomComponent != null && previousRoomComponent != null)
                {
                    nextRoomComponent.ActivateRoom(true);
                    previousRoomComponent.ActivateRoom(false);
                }
                else
                {
                    Debug.LogError("Room component is missing on nextRoom or previousRoom.");
                }
            }
            else
            {
                cam.MoveToNewRoom(previousRoom);
                var nextRoomComponent = nextRoom.GetComponent<Room>();
                var previousRoomComponent = previousRoom.GetComponent<Room>();

                if (nextRoomComponent != null && previousRoomComponent != null)
                {
                    previousRoomComponent.ActivateRoom(true);
                    nextRoomComponent.ActivateRoom(false);
                }
                else
                {
                    Debug.LogError("Room component is missing on nextRoom or previousRoom.");
                }
            }
        }
    }
}

