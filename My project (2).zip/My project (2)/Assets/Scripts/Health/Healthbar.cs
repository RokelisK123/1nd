using UnityEngine;
using UnityEngine.UI;

public class Healthbar : MonoBehaviour
{
    [SerializeField] private Health playerHealth;
    [SerializeField] private Image totalHealthbar;
    [SerializeField] private Image currentHealthbar;


  
       private void Update()
        {
            System.Action<float> updateHealth = (currentHealth) =>
            {
                currentHealthbar.fillAmount = currentHealth / 10;
            };

            updateHealth(playerHealth.currentHealth);
        }
    }

