using UnityEngine;

public class PlayerRespawn : MonoBehaviour
{
    [SerializeField] private Transform defaultSpawnPoint;
    private Transform currentCheckpoint;
    private Health playerHealth;

    private void Awake()
    {
        playerHealth = GetComponent<Health>();
    }

    public void Respawn()
    {
        if (currentCheckpoint == null)
        {
            Debug.LogWarning("default spawn point.");
            transform.position = defaultSpawnPoint.position; // default spawn
        }
        else
        {
            transform.position = currentCheckpoint.position; // checkpoint
            Camera.main.GetComponent<CameraController>().MoveToNewRoom(currentCheckpoint.parent); 
        }

        playerHealth.Respawn(); 
    }



    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.tag == "Checkpoint")
        {
            currentCheckpoint = collision.transform;
            collision.GetComponent<Collider2D>().enabled = false;
            collision.GetComponent<Animator>().SetTrigger("activate");
        }
    }
}
