using UnityEngine;

public abstract class Character : MonoBehaviour
{
    public abstract void Move(float speed);
    public abstract void TakeDamage(float damage);
}

public class Player : Character
{
    private float currentHealth = 100f;

    public override void Move(float speed)
    {
        // Implement movement logic
        transform.Translate(speed * Time.deltaTime, 0, 0);
    }

    public override void TakeDamage(float damage)
    {
        currentHealth -= damage;
        Debug.Log("Player took damage. Current health: " + currentHealth);
    }
}

public class Enemy : Character
{
    private float currentHealth = 50f;

    public override void Move(float speed)
    {
        // Implement movement logic for enemies
        transform.Translate(speed * Time.deltaTime, 0, 0);
    }

    public override void TakeDamage(float damage)
    {
        currentHealth -= damage;
        Debug.Log("Enemy took damage. Current health: " + currentHealth);
    }
}

